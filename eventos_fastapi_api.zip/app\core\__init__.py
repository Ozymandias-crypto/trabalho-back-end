"""Core application utilities."""

