from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.enums import RegistrationStatus
from app.schemas.payment import PaymentConfirmation
from app.schemas.registration import RegistrationCreate, RegistrationPage, RegistrationRead
from app.services.registrations import RegistrationService

router = APIRouter(prefix="/registrations", tags=["registrations"])


@router.post("", response_model=RegistrationRead, status_code=status.HTTP_201_CREATED)
def create_registration(payload: RegistrationCreate, db: Session = Depends(get_db)) -> RegistrationRead:
    return RegistrationService(db).create(payload)


@router.get("", response_model=RegistrationPage)
def list_registrations(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    event_id: int | None = Query(default=None, gt=0),
    attendee_id: int | None = Query(default=None, gt=0),
    status_filter: RegistrationStatus | None = Query(default=None, alias="status"),
    db: Session = Depends(get_db),
) -> RegistrationPage:
    items, total = RegistrationService(db).list(
        limit=limit,
        offset=offset,
        event_id=event_id,
        attendee_id=attendee_id,
        status_filter=status_filter,
    )
    return RegistrationPage(items=items, total=total, limit=limit, offset=offset)


@router.post("/{registration_id}/confirm-payment", response_model=RegistrationRead)
def confirm_registration_payment(
    registration_id: int,
    payload: PaymentConfirmation,
    db: Session = Depends(get_db),
) -> RegistrationRead:
    return RegistrationService(db).confirm_payment(registration_id, payload)


@router.post("/{registration_id}/cancel", response_model=RegistrationRead)
def cancel_registration(registration_id: int, db: Session = Depends(get_db)) -> RegistrationRead:
    return RegistrationService(db).cancel(registration_id)


@router.post("/{registration_id}/check-in", response_model=RegistrationRead)
def check_in_registration(registration_id: int, db: Session = Depends(get_db)) -> RegistrationRead:
    return RegistrationService(db).check_in(registration_id)

