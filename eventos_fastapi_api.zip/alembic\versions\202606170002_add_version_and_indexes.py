"""add event version and query indexes

Revision ID: 202606170002
Revises: 202606170001
Create Date: 2026-06-17 16:25:00
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "202606170002"
down_revision: Union[str, None] = "202606170001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("events", sa.Column("version", sa.Integer(), server_default="1", nullable=False))
    op.create_check_constraint("ck_events_version_positive", "events", "version > 0")
    op.create_index("ix_events_status_starts_at", "events", ["status", "starts_at"])
    op.create_index("ix_ticket_types_event_active", "ticket_types", ["event_id", "is_active"])
    op.alter_column("events", "version", server_default=None)


def downgrade() -> None:
    op.drop_index("ix_ticket_types_event_active", table_name="ticket_types")
    op.drop_index("ix_events_status_starts_at", table_name="events")
    op.drop_constraint("ck_events_version_positive", "events", type_="check")
    op.drop_column("events", "version")

