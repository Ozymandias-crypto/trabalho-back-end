from typing import Any

from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog


class AuditLogRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def add(self, *, entity_type: str, entity_id: int, action: str, details: dict[str, Any] | None = None) -> AuditLog:
        audit_log = AuditLog(
            entity_type=entity_type,
            entity_id=entity_id,
            action=action,
            details=details or {},
        )
        self.db.add(audit_log)
        self.db.flush()
        return audit_log

