from enum import Enum


class EventStatus(str, Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    CANCELED = "canceled"
    FINISHED = "finished"


class RegistrationStatus(str, Enum):
    PENDING_PAYMENT = "pending_payment"
    CONFIRMED = "confirmed"
    CHECKED_IN = "checked_in"
    CANCELED = "canceled"


class PaymentStatus(str, Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    REFUNDED = "refunded"


ACTIVE_REGISTRATION_STATUSES = (
    RegistrationStatus.PENDING_PAYMENT,
    RegistrationStatus.CONFIRMED,
    RegistrationStatus.CHECKED_IN,
)

