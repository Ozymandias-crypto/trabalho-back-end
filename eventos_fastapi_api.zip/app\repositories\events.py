from datetime import datetime

from sqlalchemy import Select, func, select
from sqlalchemy.orm import Session, selectinload

from app.models.enums import EventStatus
from app.models.event import Event


class EventRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, event: Event) -> Event:
        self.db.add(event)
        self.db.flush()
        return event

    def get(self, event_id: int) -> Event | None:
        return self.db.scalar(
            select(Event)
            .options(selectinload(Event.venue), selectinload(Event.ticket_types))
            .where(Event.id == event_id)
        )

    def get_for_update(self, event_id: int) -> Event | None:
        return self.db.scalar(
            select(Event)
            .options(selectinload(Event.venue), selectinload(Event.ticket_types))
            .where(Event.id == event_id)
            .with_for_update()
        )

    def list(
        self,
        *,
        limit: int,
        offset: int,
        status: EventStatus | None = None,
        venue_id: int | None = None,
        starts_after: datetime | None = None,
        starts_before: datetime | None = None,
    ) -> tuple[list[Event], int]:
        stmt = self._apply_filters(
            select(Event).order_by(Event.starts_at, Event.id),
            status=status,
            venue_id=venue_id,
            starts_after=starts_after,
            starts_before=starts_before,
        )
        count_stmt = self._apply_filters(
            select(func.count()).select_from(Event),
            status=status,
            venue_id=venue_id,
            starts_after=starts_after,
            starts_before=starts_before,
        )
        items = list(self.db.scalars(stmt.limit(limit).offset(offset)).all())
        total = int(self.db.scalar(count_stmt) or 0)
        return items, total

    @staticmethod
    def _apply_filters(
        stmt: Select,
        *,
        status: EventStatus | None,
        venue_id: int | None,
        starts_after: datetime | None,
        starts_before: datetime | None,
    ) -> Select:
        if status is not None:
            stmt = stmt.where(Event.status == status)
        if venue_id is not None:
            stmt = stmt.where(Event.venue_id == venue_id)
        if starts_after is not None:
            stmt = stmt.where(Event.starts_at >= starts_after)
        if starts_before is not None:
            stmt = stmt.where(Event.starts_at <= starts_before)
        return stmt

