from __future__ import annotations

from datetime import datetime

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Integer, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.enums import RegistrationStatus
from app.models.types import enum_type


class Registration(Base):
    __tablename__ = "registrations"
    __table_args__ = (
        CheckConstraint("total_price_cents >= 0", name="ck_registrations_total_non_negative"),
        UniqueConstraint("event_id", "attendee_id", name="uq_registrations_event_attendee"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    attendee_id: Mapped[int] = mapped_column(ForeignKey("attendees.id"), nullable=False, index=True)
    ticket_type_id: Mapped[int] = mapped_column(ForeignKey("ticket_types.id"), nullable=False, index=True)
    status: Mapped[RegistrationStatus] = mapped_column(
        enum_type(RegistrationStatus),
        default=RegistrationStatus.PENDING_PAYMENT,
        nullable=False,
    )
    total_price_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    checked_in_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    canceled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    event: Mapped["Event"] = relationship(back_populates="registrations")
    attendee: Mapped["Attendee"] = relationship(back_populates="registrations")
    ticket_type: Mapped["TicketType"] = relationship(back_populates="registrations")
    payment: Mapped["Payment | None"] = relationship(back_populates="registration", uselist=False)

