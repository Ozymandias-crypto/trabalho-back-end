"""Event registration API package."""

