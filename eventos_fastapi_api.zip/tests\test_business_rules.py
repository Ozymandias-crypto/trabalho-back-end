from fastapi.testclient import TestClient

STARTS_AT = "2099-05-10T10:00:00Z"
ENDS_AT = "2099-05-10T18:00:00Z"
SALES_START = "2026-01-01T00:00:00Z"
SALES_END = "2099-05-01T00:00:00Z"


def create_venue(client: TestClient, capacity: int = 2) -> dict:
    response = client.post(
        "/venues",
        json={
            "name": "Centro de Convencoes",
            "address": "Av. Central, 100",
            "capacity": capacity,
        },
    )
    assert response.status_code == 201
    return response.json()


def create_event(client: TestClient, venue_id: int, capacity: int | None = None, title: str = "FastAPI Summit") -> dict:
    payload = {
        "venue_id": venue_id,
        "title": title,
        "description": "Evento tecnico",
        "starts_at": STARTS_AT,
        "ends_at": ENDS_AT,
    }
    if capacity is not None:
        payload["capacity_override"] = capacity
    response = client.post("/events", json=payload)
    assert response.status_code == 201
    return response.json()


def create_ticket_type(client: TestClient, event_id: int, capacity: int = 2, price_cents: int = 15000) -> dict:
    response = client.post(
        f"/events/{event_id}/ticket-types",
        json={
            "name": f"Ingresso {capacity}-{price_cents}",
            "price_cents": price_cents,
            "capacity": capacity,
            "sales_start": SALES_START,
            "sales_end": SALES_END,
        },
    )
    assert response.status_code == 201
    return response.json()


def create_attendee(client: TestClient, email: str) -> dict:
    response = client.post(
        "/attendees",
        json={"name": "Ada Lovelace", "email": email, "document": "DOC12345"},
    )
    assert response.status_code == 201
    return response.json()


def create_published_event_with_ticket(client: TestClient, event_capacity: int = 2, ticket_capacity: int = 2) -> tuple[dict, dict]:
    venue = create_venue(client, capacity=event_capacity)
    event = create_event(client, venue["id"], capacity=event_capacity)
    ticket_type = create_ticket_type(client, event["id"], capacity=ticket_capacity)
    response = client.post(f"/events/{event['id']}/publish")
    assert response.status_code == 200
    return response.json(), ticket_type


def create_registration(client: TestClient, event_id: int, ticket_type_id: int, attendee_id: int) -> dict:
    response = client.post(
        "/registrations",
        json={
            "event_id": event_id,
            "ticket_type_id": ticket_type_id,
            "attendee_id": attendee_id,
        },
    )
    assert response.status_code == 201
    return response.json()


def test_rejects_event_with_invalid_dates(client: TestClient) -> None:
    venue = create_venue(client)

    response = client.post(
        "/events",
        json={
            "venue_id": venue["id"],
            "title": "Datas invalidas",
            "starts_at": ENDS_AT,
            "ends_at": STARTS_AT,
        },
    )

    assert response.status_code == 422
    assert response.json()["error"] == "VALIDATION_ERROR"


def test_rejects_publish_without_ticket_type(client: TestClient) -> None:
    venue = create_venue(client)
    event = create_event(client, venue["id"])

    response = client.post(f"/events/{event['id']}/publish")

    assert response.status_code == 400
    assert response.json()["error"] == "EVENT_WITHOUT_TICKETS"


def test_rejects_ticket_capacity_greater_than_event_capacity(client: TestClient) -> None:
    venue = create_venue(client, capacity=1)
    event = create_event(client, venue["id"], capacity=1)

    response = client.post(
        f"/events/{event['id']}/ticket-types",
        json={
            "name": "Lote unico",
            "price_cents": 1000,
            "capacity": 2,
            "sales_start": SALES_START,
            "sales_end": SALES_END,
        },
    )

    assert response.status_code == 400
    assert response.json()["error"] == "TICKET_CAPACITY_EXCEEDS_EVENT"


def test_rejects_registration_for_draft_event(client: TestClient) -> None:
    venue = create_venue(client)
    event = create_event(client, venue["id"])
    ticket_type = create_ticket_type(client, event["id"])
    attendee = create_attendee(client, "ada@example.com")

    response = client.post(
        "/registrations",
        json={
            "event_id": event["id"],
            "ticket_type_id": ticket_type["id"],
            "attendee_id": attendee["id"],
        },
    )

    assert response.status_code == 400
    assert response.json()["error"] == "EVENT_NOT_AVAILABLE"


def test_rejects_registration_when_capacity_is_exhausted(client: TestClient) -> None:
    event, ticket_type = create_published_event_with_ticket(client, event_capacity=1, ticket_capacity=1)
    first_attendee = create_attendee(client, "first@example.com")
    second_attendee = create_attendee(client, "second@example.com")
    create_registration(client, event["id"], ticket_type["id"], first_attendee["id"])

    response = client.post(
        "/registrations",
        json={
            "event_id": event["id"],
            "ticket_type_id": ticket_type["id"],
            "attendee_id": second_attendee["id"],
        },
    )

    assert response.status_code == 409
    assert response.json()["error"] == "EVENT_CAPACITY_EXHAUSTED"


def test_rejects_duplicate_registration(client: TestClient) -> None:
    event, ticket_type = create_published_event_with_ticket(client)
    attendee = create_attendee(client, "duplicate@example.com")
    create_registration(client, event["id"], ticket_type["id"], attendee["id"])

    response = client.post(
        "/registrations",
        json={
            "event_id": event["id"],
            "ticket_type_id": ticket_type["id"],
            "attendee_id": attendee["id"],
        },
    )

    assert response.status_code == 409
    assert response.json()["error"] == "DUPLICATE_REGISTRATION"


def test_confirm_payment_moves_registration_to_confirmed(client: TestClient) -> None:
    event, ticket_type = create_published_event_with_ticket(client)
    attendee = create_attendee(client, "pay@example.com")
    registration = create_registration(client, event["id"], ticket_type["id"], attendee["id"])

    response = client.post(
        f"/registrations/{registration['id']}/confirm-payment",
        json={"provider_reference": "PAY-001"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "confirmed"
    assert body["payment"]["status"] == "paid"
    assert body["payment"]["provider_reference"] == "PAY-001"


def test_rejects_duplicate_payment_reference(client: TestClient) -> None:
    event, ticket_type = create_published_event_with_ticket(client)
    attendee_one = create_attendee(client, "one@example.com")
    attendee_two = create_attendee(client, "two@example.com")
    registration_one = create_registration(client, event["id"], ticket_type["id"], attendee_one["id"])
    registration_two = create_registration(client, event["id"], ticket_type["id"], attendee_two["id"])

    first_response = client.post(
        f"/registrations/{registration_one['id']}/confirm-payment",
        json={"provider_reference": "PAY-SAME"},
    )
    assert first_response.status_code == 200

    second_response = client.post(
        f"/registrations/{registration_two['id']}/confirm-payment",
        json={"provider_reference": "PAY-SAME"},
    )

    assert second_response.status_code == 409
    assert second_response.json()["error"] == "PAYMENT_REFERENCE_ALREADY_USED"


def test_cancel_confirmed_registration_refunds_payment(client: TestClient) -> None:
    event, ticket_type = create_published_event_with_ticket(client)
    attendee = create_attendee(client, "refund@example.com")
    registration = create_registration(client, event["id"], ticket_type["id"], attendee["id"])
    client.post(f"/registrations/{registration['id']}/confirm-payment", json={"provider_reference": "PAY-REFUND"})

    response = client.post(f"/registrations/{registration['id']}/cancel")

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "canceled"
    assert body["payment"]["status"] == "refunded"


def test_checked_in_registration_cannot_be_canceled(client: TestClient) -> None:
    event, ticket_type = create_published_event_with_ticket(client)
    attendee = create_attendee(client, "checkin@example.com")
    registration = create_registration(client, event["id"], ticket_type["id"], attendee["id"])
    client.post(f"/registrations/{registration['id']}/confirm-payment", json={"provider_reference": "PAY-CHECKIN"})
    check_in_response = client.post(f"/registrations/{registration['id']}/check-in")
    assert check_in_response.status_code == 200

    response = client.post(f"/registrations/{registration['id']}/cancel")

    assert response.status_code == 400
    assert response.json()["error"] == "REGISTRATION_TERMINAL_STATE"


def test_events_endpoint_supports_filters_and_pagination(client: TestClient) -> None:
    venue = create_venue(client, capacity=4)
    draft_event = create_event(client, venue["id"], capacity=2, title="Evento rascunho")
    published_event = create_event(client, venue["id"], capacity=2, title="Evento publicado")
    create_ticket_type(client, published_event["id"], capacity=2)
    publish_response = client.post(f"/events/{published_event['id']}/publish")
    assert publish_response.status_code == 200

    response = client.get("/events", params={"status": "published", "limit": 1, "offset": 0})

    assert response.status_code == 200
    body = response.json()
    assert body["total"] == 1
    assert body["limit"] == 1
    assert body["items"][0]["id"] == published_event["id"]
    assert draft_event["status"] == "draft"


def test_availability_returns_derived_capacity(client: TestClient) -> None:
    event, ticket_type = create_published_event_with_ticket(client, event_capacity=2, ticket_capacity=2)
    attendee = create_attendee(client, "availability@example.com")
    create_registration(client, event["id"], ticket_type["id"], attendee["id"])

    response = client.get(f"/events/{event['id']}/availability")

    assert response.status_code == 200
    assert response.json() == {
        "event_id": event["id"],
        "capacity": 2,
        "reserved_seats": 1,
        "available_seats": 1,
    }

