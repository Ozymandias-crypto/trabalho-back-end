from sqlalchemy.orm import Session

from app.models.venue import Venue
from app.repositories.audit_logs import AuditLogRepository
from app.repositories.venues import VenueRepository
from app.schemas.venue import VenueCreate


class VenueService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.venues = VenueRepository(db)
        self.audit_logs = AuditLogRepository(db)

    def create(self, payload: VenueCreate) -> Venue:
        venue = Venue(**payload.model_dump())
        self.venues.create(venue)
        self.audit_logs.add(
            entity_type="venue",
            entity_id=venue.id,
            action="created",
            details={"capacity": venue.capacity},
        )
        self.db.commit()
        return venue

