from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.models.enums import PaymentStatus


class PaymentConfirmation(BaseModel):
    provider_reference: str = Field(min_length=3, max_length=120)


class PaymentRead(BaseModel):
    id: int
    registration_id: int
    amount_cents: int
    status: PaymentStatus
    provider_reference: str | None
    paid_at: datetime | None
    refunded_at: datetime | None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

