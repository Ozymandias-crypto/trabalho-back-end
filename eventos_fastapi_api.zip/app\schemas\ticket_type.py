from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def _normalize_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


class TicketTypeCreate(BaseModel):
    name: str = Field(min_length=3, max_length=80)
    price_cents: int = Field(ge=0)
    capacity: int = Field(gt=0)
    sales_start: datetime
    sales_end: datetime
    is_active: bool = True

    @field_validator("sales_start", "sales_end")
    @classmethod
    def normalize_sale_dates(cls, value: datetime) -> datetime:
        return _normalize_datetime(value)

    @model_validator(mode="after")
    def validate_sales_window(self) -> "TicketTypeCreate":
        if self.sales_end <= self.sales_start:
            raise ValueError("sales_end deve ser maior que sales_start")
        return self


class TicketTypeRead(BaseModel):
    id: int
    event_id: int
    name: str
    price_cents: int
    capacity: int
    sales_start: datetime
    sales_end: datetime
    is_active: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

