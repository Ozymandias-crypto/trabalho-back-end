from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.venue import Venue


class VenueRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, venue: Venue) -> Venue:
        self.db.add(venue)
        self.db.flush()
        return venue

    def get(self, venue_id: int) -> Venue | None:
        return self.db.scalar(select(Venue).where(Venue.id == venue_id))

