from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import IntegrityError

from app.core.exceptions import BusinessError, business_error_handler, integrity_error_handler, validation_error_handler
from app.routers import attendees, events, registrations, venues

app = FastAPI(
    title="Eventus API",
    version="1.0.0",
    description="API REST para plataforma de eventos com inscricoes, ingressos, pagamentos e check-in.",
)

app.add_exception_handler(BusinessError, business_error_handler)
app.add_exception_handler(RequestValidationError, validation_error_handler)
app.add_exception_handler(IntegrityError, integrity_error_handler)

app.include_router(venues.router)
app.include_router(attendees.router)
app.include_router(events.router)
app.include_router(registrations.router)


@app.get("/health", tags=["health"])
def health_check() -> dict[str, str]:
    return {"status": "ok"}

