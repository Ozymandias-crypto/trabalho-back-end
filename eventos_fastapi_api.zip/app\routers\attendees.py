from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.schemas.attendee import AttendeeCreate, AttendeeRead
from app.services.attendees import AttendeeService

router = APIRouter(prefix="/attendees", tags=["attendees"])


@router.post("", response_model=AttendeeRead, status_code=status.HTTP_201_CREATED)
def create_attendee(payload: AttendeeCreate, db: Session = Depends(get_db)) -> AttendeeRead:
    return AttendeeService(db).create(payload)

