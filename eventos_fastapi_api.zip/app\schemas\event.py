from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.models.enums import EventStatus


def _normalize_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


class EventCreate(BaseModel):
    venue_id: int = Field(gt=0)
    title: str = Field(min_length=3, max_length=160)
    description: str | None = Field(default=None, max_length=3000)
    starts_at: datetime
    ends_at: datetime
    capacity_override: int | None = Field(default=None, gt=0)

    @field_validator("starts_at", "ends_at")
    @classmethod
    def datetimes_must_have_timezone(cls, value: datetime) -> datetime:
        return _normalize_datetime(value)

    @model_validator(mode="after")
    def end_must_be_after_start(self) -> "EventCreate":
        if self.ends_at <= self.starts_at:
            raise ValueError("ends_at deve ser maior que starts_at")
        return self


class EventRead(BaseModel):
    id: int
    venue_id: int
    title: str
    description: str | None
    starts_at: datetime
    ends_at: datetime
    capacity_override: int | None
    status: EventStatus
    version: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class EventPage(BaseModel):
    items: list[EventRead]
    total: int
    limit: int
    offset: int


class EventAvailability(BaseModel):
    event_id: int
    capacity: int
    reserved_seats: int
    available_seats: int

