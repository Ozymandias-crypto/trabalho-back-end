from fastapi import status
from sqlalchemy.orm import Session

from app.core.exceptions import BusinessError
from app.core.time import as_utc, utc_now
from app.models.enums import EventStatus
from app.models.ticket_type import TicketType
from app.repositories.audit_logs import AuditLogRepository
from app.repositories.events import EventRepository
from app.repositories.ticket_types import TicketTypeRepository
from app.schemas.ticket_type import TicketTypeCreate
from app.services.events import EventService


class TicketTypeService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.events = EventRepository(db)
        self.ticket_types = TicketTypeRepository(db)
        self.audit_logs = AuditLogRepository(db)

    def create(self, event_id: int, payload: TicketTypeCreate) -> TicketType:
        event = self.events.get_for_update(event_id)
        if event is None:
            raise BusinessError("EVENT_NOT_FOUND", "O evento informado nao existe.", {"event_id": event_id}, status.HTTP_404_NOT_FOUND)
        if event.status != EventStatus.DRAFT:
            raise BusinessError(
                "TICKET_EVENT_LOCKED",
                "Tipos de ingresso so podem ser cadastrados enquanto o evento esta em rascunho.",
                {"event_id": event.id, "event_status": event.status.value},
            )
        if as_utc(payload.sales_end) > as_utc(event.starts_at):
            raise BusinessError(
                "INVALID_SALES_WINDOW",
                "A venda de ingressos precisa terminar antes do inicio do evento.",
                {"sales_end": payload.sales_end.isoformat(), "event_starts_at": event.starts_at.isoformat()},
            )
        if as_utc(payload.sales_end) <= utc_now():
            raise BusinessError(
                "SALES_WINDOW_ALREADY_CLOSED",
                "Nao e possivel criar um ingresso cuja janela de venda ja terminou.",
                {"sales_end": payload.sales_end.isoformat()},
            )

        event_capacity = EventService(self.db).capacity_for(event)
        current_ticket_capacity = self.ticket_types.sum_capacity_for_event(event.id)
        if current_ticket_capacity + payload.capacity > event_capacity:
            raise BusinessError(
                "TICKET_CAPACITY_EXCEEDS_EVENT",
                "A soma das capacidades dos ingressos nao pode superar a capacidade do evento.",
                {
                    "current_ticket_capacity": current_ticket_capacity,
                    "new_ticket_capacity": payload.capacity,
                    "event_capacity": event_capacity,
                },
            )

        ticket_type = TicketType(event_id=event.id, **payload.model_dump())
        self.ticket_types.create(ticket_type)
        self.audit_logs.add(
            entity_type="ticket_type",
            entity_id=ticket_type.id,
            action="created",
            details={"event_id": event.id, "capacity": ticket_type.capacity},
        )
        self.db.commit()
        return ticket_type

