from datetime import datetime

from fastapi import status
from sqlalchemy.orm import Session

from app.core.exceptions import BusinessError
from app.core.time import as_utc, utc_now
from app.models.enums import ACTIVE_REGISTRATION_STATUSES, EventStatus, PaymentStatus, RegistrationStatus
from app.models.event import Event
from app.repositories.audit_logs import AuditLogRepository
from app.repositories.events import EventRepository
from app.repositories.registrations import RegistrationRepository
from app.repositories.ticket_types import TicketTypeRepository
from app.repositories.venues import VenueRepository
from app.schemas.event import EventCreate


class EventService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.events = EventRepository(db)
        self.venues = VenueRepository(db)
        self.ticket_types = TicketTypeRepository(db)
        self.registrations = RegistrationRepository(db)
        self.audit_logs = AuditLogRepository(db)

    def create(self, payload: EventCreate) -> Event:
        venue = self.venues.get(payload.venue_id)
        if venue is None:
            raise BusinessError("VENUE_NOT_FOUND", "O local informado nao existe.", {"venue_id": payload.venue_id}, status.HTTP_404_NOT_FOUND)
        if not venue.is_active:
            raise BusinessError("VENUE_INACTIVE", "Nao e possivel criar evento em um local inativo.", {"venue_id": venue.id})
        if as_utc(payload.starts_at) <= utc_now():
            raise BusinessError("EVENT_START_IN_PAST", "O evento precisa iniciar no futuro.", {"starts_at": payload.starts_at.isoformat()})
        if payload.capacity_override is not None and payload.capacity_override > venue.capacity:
            raise BusinessError(
                "EVENT_CAPACITY_EXCEEDS_VENUE",
                "A capacidade do evento nao pode ser maior que a capacidade do local.",
                {"event_capacity": payload.capacity_override, "venue_capacity": venue.capacity},
            )

        event = Event(status=EventStatus.DRAFT, version=1, **payload.model_dump())
        self.events.create(event)
        self.audit_logs.add(
            entity_type="event",
            entity_id=event.id,
            action="created",
            details={"status": event.status.value},
        )
        self.db.commit()
        return event

    def list(
        self,
        *,
        limit: int,
        offset: int,
        status_filter: EventStatus | None = None,
        venue_id: int | None = None,
        starts_after: datetime | None = None,
        starts_before: datetime | None = None,
    ) -> tuple[list[Event], int]:
        return self.events.list(
            limit=limit,
            offset=offset,
            status=status_filter,
            venue_id=venue_id,
            starts_after=starts_after,
            starts_before=starts_before,
        )

    def publish(self, event_id: int) -> Event:
        event = self._get_event_for_update(event_id)
        if event.status != EventStatus.DRAFT:
            raise BusinessError(
                "INVALID_EVENT_TRANSITION",
                "Apenas eventos em rascunho podem ser publicados.",
                {"current_status": event.status.value, "target_status": EventStatus.PUBLISHED.value},
            )
        if not event.venue.is_active:
            raise BusinessError("VENUE_INACTIVE", "Nao e possivel publicar evento em local inativo.", {"venue_id": event.venue_id})
        if as_utc(event.starts_at) <= utc_now():
            raise BusinessError("EVENT_START_IN_PAST", "Nao e possivel publicar evento que ja iniciou.", {"event_id": event.id})
        if self.ticket_types.count_active_for_event(event.id) == 0:
            raise BusinessError(
                "EVENT_WITHOUT_TICKETS",
                "O evento precisa ter pelo menos um tipo de ingresso ativo antes de ser publicado.",
                {"event_id": event.id},
            )
        total_ticket_capacity = self.ticket_types.sum_capacity_for_event(event.id)
        capacity = self.capacity_for(event)
        if total_ticket_capacity > capacity:
            raise BusinessError(
                "TICKET_CAPACITY_EXCEEDS_EVENT",
                "A soma das capacidades dos ingressos nao pode superar a capacidade do evento.",
                {"ticket_capacity": total_ticket_capacity, "event_capacity": capacity},
            )

        event.status = EventStatus.PUBLISHED
        event.version += 1
        self.audit_logs.add(
            entity_type="event",
            entity_id=event.id,
            action="published",
            details={"version": event.version},
        )
        self.db.commit()
        return event

    def cancel(self, event_id: int) -> Event:
        event = self._get_event_for_update(event_id)
        if event.status in (EventStatus.CANCELED, EventStatus.FINISHED):
            raise BusinessError(
                "EVENT_TERMINAL_STATE",
                "Eventos cancelados ou finalizados nao podem mudar de estado.",
                {"current_status": event.status.value},
            )

        now = utc_now()
        event.status = EventStatus.CANCELED
        event.version += 1

        active_registrations = self.registrations.list_active_for_event(event.id)
        checked_in_ids = [
            registration.id
            for registration in active_registrations
            if registration.status == RegistrationStatus.CHECKED_IN
        ]
        if checked_in_ids:
            raise BusinessError(
                "EVENT_HAS_CHECKED_IN_REGISTRATIONS",
                "Nao e possivel cancelar um evento com check-ins ja realizados.",
                {"registration_ids": checked_in_ids},
                status.HTTP_409_CONFLICT,
            )

        affected_registrations = []
        for registration in active_registrations:
            registration.status = RegistrationStatus.CANCELED
            registration.canceled_at = now
            affected_registrations.append(registration.id)
            if registration.payment and registration.payment.status == PaymentStatus.PAID:
                registration.payment.status = PaymentStatus.REFUNDED
                registration.payment.refunded_at = now

        self.audit_logs.add(
            entity_type="event",
            entity_id=event.id,
            action="canceled",
            details={
                "version": event.version,
                "affected_registrations": affected_registrations,
                "active_statuses": [item.value for item in ACTIVE_REGISTRATION_STATUSES],
            },
        )
        self.db.commit()
        return event

    def availability(self, event_id: int) -> dict[str, int]:
        event = self.events.get(event_id)
        if event is None:
            raise BusinessError("EVENT_NOT_FOUND", "O evento informado nao existe.", {"event_id": event_id}, status.HTTP_404_NOT_FOUND)
        capacity = self.capacity_for(event)
        reserved = self.registrations.count_active_by_event(event.id)
        return {
            "event_id": event.id,
            "capacity": capacity,
            "reserved_seats": reserved,
            "available_seats": max(capacity - reserved, 0),
        }

    def capacity_for(self, event: Event) -> int:
        return event.capacity_override or event.venue.capacity

    def _get_event_for_update(self, event_id: int) -> Event:
        event = self.events.get_for_update(event_id)
        if event is None:
            raise BusinessError("EVENT_NOT_FOUND", "O evento informado nao existe.", {"event_id": event_id}, status.HTTP_404_NOT_FOUND)
        return event
