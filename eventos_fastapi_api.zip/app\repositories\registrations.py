from sqlalchemy import Select, func, select
from sqlalchemy.orm import Session, selectinload

from app.models.enums import ACTIVE_REGISTRATION_STATUSES, RegistrationStatus
from app.models.registration import Registration


class RegistrationRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, registration: Registration) -> Registration:
        self.db.add(registration)
        self.db.flush()
        return registration

    def get(self, registration_id: int) -> Registration | None:
        return self.db.scalar(
            select(Registration)
            .options(
                selectinload(Registration.event),
                selectinload(Registration.ticket_type),
                selectinload(Registration.payment),
            )
            .where(Registration.id == registration_id)
        )

    def get_for_update(self, registration_id: int) -> Registration | None:
        return self.db.scalar(
            select(Registration)
            .options(
                selectinload(Registration.event),
                selectinload(Registration.ticket_type),
                selectinload(Registration.payment),
            )
            .where(Registration.id == registration_id)
            .with_for_update()
        )

    def get_by_event_and_attendee(self, event_id: int, attendee_id: int) -> Registration | None:
        return self.db.scalar(
            select(Registration).where(
                Registration.event_id == event_id,
                Registration.attendee_id == attendee_id,
            )
        )

    def count_active_by_event(self, event_id: int) -> int:
        stmt = (
            select(func.count())
            .select_from(Registration)
            .where(
                Registration.event_id == event_id,
                Registration.status.in_(ACTIVE_REGISTRATION_STATUSES),
            )
        )
        return int(self.db.scalar(stmt) or 0)

    def count_active_by_ticket_type(self, ticket_type_id: int) -> int:
        stmt = (
            select(func.count())
            .select_from(Registration)
            .where(
                Registration.ticket_type_id == ticket_type_id,
                Registration.status.in_(ACTIVE_REGISTRATION_STATUSES),
            )
        )
        return int(self.db.scalar(stmt) or 0)

    def list_active_for_event(self, event_id: int) -> list[Registration]:
        stmt = (
            select(Registration)
            .options(selectinload(Registration.payment))
            .where(
                Registration.event_id == event_id,
                Registration.status.in_(ACTIVE_REGISTRATION_STATUSES),
            )
        )
        return list(self.db.scalars(stmt).all())

    def list(
        self,
        *,
        limit: int,
        offset: int,
        event_id: int | None = None,
        attendee_id: int | None = None,
        status: RegistrationStatus | None = None,
    ) -> tuple[list[Registration], int]:
        stmt = self._apply_filters(
            select(Registration)
            .options(selectinload(Registration.payment))
            .order_by(Registration.created_at.desc(), Registration.id.desc()),
            event_id=event_id,
            attendee_id=attendee_id,
            status=status,
        )
        count_stmt = self._apply_filters(
            select(func.count()).select_from(Registration),
            event_id=event_id,
            attendee_id=attendee_id,
            status=status,
        )
        items = list(self.db.scalars(stmt.limit(limit).offset(offset)).all())
        total = int(self.db.scalar(count_stmt) or 0)
        return items, total

    @staticmethod
    def _apply_filters(
        stmt: Select,
        *,
        event_id: int | None,
        attendee_id: int | None,
        status: RegistrationStatus | None,
    ) -> Select:
        if event_id is not None:
            stmt = stmt.where(Registration.event_id == event_id)
        if attendee_id is not None:
            stmt = stmt.where(Registration.attendee_id == attendee_id)
        if status is not None:
            stmt = stmt.where(Registration.status == status)
        return stmt

