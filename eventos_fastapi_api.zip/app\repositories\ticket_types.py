from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.ticket_type import TicketType


class TicketTypeRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, ticket_type: TicketType) -> TicketType:
        self.db.add(ticket_type)
        self.db.flush()
        return ticket_type

    def get(self, ticket_type_id: int) -> TicketType | None:
        return self.db.scalar(select(TicketType).where(TicketType.id == ticket_type_id))

    def get_for_update(self, ticket_type_id: int) -> TicketType | None:
        return self.db.scalar(select(TicketType).where(TicketType.id == ticket_type_id).with_for_update())

    def count_active_for_event(self, event_id: int) -> int:
        stmt = (
            select(func.count())
            .select_from(TicketType)
            .where(TicketType.event_id == event_id, TicketType.is_active.is_(True))
        )
        return int(self.db.scalar(stmt) or 0)

    def sum_capacity_for_event(self, event_id: int) -> int:
        stmt = (
            select(func.coalesce(func.sum(TicketType.capacity), 0))
            .select_from(TicketType)
            .where(TicketType.event_id == event_id, TicketType.is_active.is_(True))
        )
        return int(self.db.scalar(stmt) or 0)

