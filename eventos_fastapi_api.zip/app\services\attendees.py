from fastapi import status
from sqlalchemy.orm import Session

from app.core.exceptions import BusinessError
from app.models.attendee import Attendee
from app.repositories.attendees import AttendeeRepository
from app.repositories.audit_logs import AuditLogRepository
from app.schemas.attendee import AttendeeCreate


class AttendeeService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.attendees = AttendeeRepository(db)
        self.audit_logs = AuditLogRepository(db)

    def create(self, payload: AttendeeCreate) -> Attendee:
        if self.attendees.get_by_email(str(payload.email)):
            raise BusinessError(
                "ATTENDEE_EMAIL_ALREADY_EXISTS",
                "Ja existe um participante cadastrado com este e-mail.",
                {"email": str(payload.email)},
                status.HTTP_409_CONFLICT,
            )

        attendee = Attendee(**payload.model_dump())
        self.attendees.create(attendee)
        self.audit_logs.add(
            entity_type="attendee",
            entity_id=attendee.id,
            action="created",
            details={"email": attendee.email},
        )
        self.db.commit()
        return attendee

