from fastapi import status
from sqlalchemy.orm import Session

from app.core.exceptions import BusinessError
from app.core.time import as_utc, utc_now
from app.models.enums import EventStatus, PaymentStatus, RegistrationStatus
from app.models.payment import Payment
from app.models.registration import Registration
from app.repositories.attendees import AttendeeRepository
from app.repositories.audit_logs import AuditLogRepository
from app.repositories.events import EventRepository
from app.repositories.payments import PaymentRepository
from app.repositories.registrations import RegistrationRepository
from app.repositories.ticket_types import TicketTypeRepository
from app.schemas.payment import PaymentConfirmation
from app.schemas.registration import RegistrationCreate
from app.services.events import EventService


class RegistrationService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.events = EventRepository(db)
        self.ticket_types = TicketTypeRepository(db)
        self.attendees = AttendeeRepository(db)
        self.registrations = RegistrationRepository(db)
        self.payments = PaymentRepository(db)
        self.audit_logs = AuditLogRepository(db)

    def create(self, payload: RegistrationCreate) -> Registration:
        event = self.events.get_for_update(payload.event_id)
        ticket_type = self.ticket_types.get_for_update(payload.ticket_type_id)
        attendee = self.attendees.get(payload.attendee_id)

        if event is None:
            raise BusinessError("EVENT_NOT_FOUND", "O evento informado nao existe.", {"event_id": payload.event_id}, status.HTTP_404_NOT_FOUND)
        if ticket_type is None:
            raise BusinessError("TICKET_TYPE_NOT_FOUND", "O tipo de ingresso informado nao existe.", {"ticket_type_id": payload.ticket_type_id}, status.HTTP_404_NOT_FOUND)
        if attendee is None:
            raise BusinessError("ATTENDEE_NOT_FOUND", "O participante informado nao existe.", {"attendee_id": payload.attendee_id}, status.HTTP_404_NOT_FOUND)
        if ticket_type.event_id != event.id:
            raise BusinessError(
                "TICKET_EVENT_MISMATCH",
                "O tipo de ingresso nao pertence ao evento informado.",
                {"event_id": event.id, "ticket_type_id": ticket_type.id},
            )
        if event.status != EventStatus.PUBLISHED:
            raise BusinessError(
                "EVENT_NOT_AVAILABLE",
                "Inscricoes so podem ser feitas em eventos publicados.",
                {"event_id": event.id, "event_status": event.status.value},
            )
        if not ticket_type.is_active:
            raise BusinessError("TICKET_TYPE_INACTIVE", "O tipo de ingresso esta inativo.", {"ticket_type_id": ticket_type.id})

        now = utc_now()
        if not (as_utc(ticket_type.sales_start) <= now <= as_utc(ticket_type.sales_end)):
            raise BusinessError(
                "OUTSIDE_SALES_WINDOW",
                "A inscricao esta fora da janela de venda do ingresso.",
                {
                    "sales_start": ticket_type.sales_start.isoformat(),
                    "sales_end": ticket_type.sales_end.isoformat(),
                },
            )
        if self.registrations.get_by_event_and_attendee(event.id, attendee.id):
            raise BusinessError(
                "DUPLICATE_REGISTRATION",
                "O participante ja possui inscricao para este evento.",
                {"event_id": event.id, "attendee_id": attendee.id},
                status.HTTP_409_CONFLICT,
            )

        event_capacity = EventService(self.db).capacity_for(event)
        event_reserved = self.registrations.count_active_by_event(event.id)
        if event_reserved >= event_capacity:
            raise BusinessError(
                "EVENT_CAPACITY_EXHAUSTED",
                "Nao ha vagas disponiveis para este evento.",
                {"event_capacity": event_capacity, "reserved_seats": event_reserved},
                status.HTTP_409_CONFLICT,
            )

        ticket_reserved = self.registrations.count_active_by_ticket_type(ticket_type.id)
        if ticket_reserved >= ticket_type.capacity:
            raise BusinessError(
                "TICKET_TYPE_SOLD_OUT",
                "Nao ha ingressos disponiveis para este tipo.",
                {"ticket_type_capacity": ticket_type.capacity, "reserved_tickets": ticket_reserved},
                status.HTTP_409_CONFLICT,
            )

        registration = Registration(
            event_id=event.id,
            attendee_id=attendee.id,
            ticket_type_id=ticket_type.id,
            status=RegistrationStatus.PENDING_PAYMENT,
            total_price_cents=ticket_type.price_cents,
        )
        self.registrations.create(registration)

        payment = Payment(
            registration_id=registration.id,
            amount_cents=registration.total_price_cents,
            status=PaymentStatus.PENDING,
        )
        self.payments.create(payment)
        registration.payment = payment

        self.audit_logs.add(
            entity_type="registration",
            entity_id=registration.id,
            action="created",
            details={"event_id": event.id, "total_price_cents": registration.total_price_cents},
        )
        self.db.commit()
        return registration

    def confirm_payment(self, registration_id: int, payload: PaymentConfirmation) -> Registration:
        registration = self._get_registration_for_update(registration_id)
        if registration.status != RegistrationStatus.PENDING_PAYMENT:
            raise BusinessError(
                "REGISTRATION_NOT_PENDING_PAYMENT",
                "Somente inscricoes aguardando pagamento podem ser confirmadas.",
                {"registration_id": registration.id, "current_status": registration.status.value},
            )
        if registration.payment is None:
            raise BusinessError("PAYMENT_NOT_FOUND", "A inscricao nao possui pagamento associado.", {"registration_id": registration.id})
        if self.payments.get_by_provider_reference(payload.provider_reference):
            raise BusinessError(
                "PAYMENT_REFERENCE_ALREADY_USED",
                "A referencia do provedor de pagamento ja foi usada.",
                {"provider_reference": payload.provider_reference},
                status.HTTP_409_CONFLICT,
            )
        if registration.payment.amount_cents != registration.total_price_cents:
            raise BusinessError(
                "PAYMENT_AMOUNT_MISMATCH",
                "O valor do pagamento nao corresponde ao total da inscricao.",
                {
                    "payment_amount_cents": registration.payment.amount_cents,
                    "registration_total_cents": registration.total_price_cents,
                },
            )

        now = utc_now()
        registration.payment.status = PaymentStatus.PAID
        registration.payment.provider_reference = payload.provider_reference
        registration.payment.paid_at = now
        registration.status = RegistrationStatus.CONFIRMED
        self.audit_logs.add(
            entity_type="registration",
            entity_id=registration.id,
            action="payment_confirmed",
            details={"provider_reference": payload.provider_reference},
        )
        self.db.commit()
        return registration

    def cancel(self, registration_id: int) -> Registration:
        registration = self._get_registration_for_update(registration_id)
        if registration.status not in (RegistrationStatus.PENDING_PAYMENT, RegistrationStatus.CONFIRMED):
            raise BusinessError(
                "REGISTRATION_TERMINAL_STATE",
                "Inscricoes canceladas ou com check-in nao podem ser canceladas.",
                {"registration_id": registration.id, "current_status": registration.status.value},
            )
        if as_utc(registration.event.starts_at) <= utc_now():
            raise BusinessError(
                "EVENT_ALREADY_STARTED",
                "Nao e possivel cancelar inscricao depois do inicio do evento.",
                {"event_id": registration.event_id, "starts_at": registration.event.starts_at.isoformat()},
            )

        now = utc_now()
        registration.status = RegistrationStatus.CANCELED
        registration.canceled_at = now
        if registration.payment:
            if registration.payment.status == PaymentStatus.PAID:
                registration.payment.status = PaymentStatus.REFUNDED
                registration.payment.refunded_at = now
            elif registration.payment.status == PaymentStatus.PENDING:
                registration.payment.status = PaymentStatus.FAILED

        self.audit_logs.add(
            entity_type="registration",
            entity_id=registration.id,
            action="canceled",
            details={"previous_status": "pending_payment_or_confirmed"},
        )
        self.db.commit()
        return registration

    def check_in(self, registration_id: int) -> Registration:
        registration = self._get_registration_for_update(registration_id)
        if registration.status != RegistrationStatus.CONFIRMED:
            raise BusinessError(
                "REGISTRATION_NOT_CONFIRMED",
                "Somente inscricoes confirmadas podem realizar check-in.",
                {"registration_id": registration.id, "current_status": registration.status.value},
            )
        if registration.event.status != EventStatus.PUBLISHED:
            raise BusinessError(
                "EVENT_NOT_AVAILABLE_FOR_CHECKIN",
                "Check-in so e permitido para eventos publicados.",
                {"event_id": registration.event_id, "event_status": registration.event.status.value},
            )

        registration.status = RegistrationStatus.CHECKED_IN
        registration.checked_in_at = utc_now()
        self.audit_logs.add(
            entity_type="registration",
            entity_id=registration.id,
            action="checked_in",
            details={"event_id": registration.event_id},
        )
        self.db.commit()
        return registration

    def list(
        self,
        *,
        limit: int,
        offset: int,
        event_id: int | None = None,
        attendee_id: int | None = None,
        status_filter: RegistrationStatus | None = None,
    ) -> tuple[list[Registration], int]:
        return self.registrations.list(
            limit=limit,
            offset=offset,
            event_id=event_id,
            attendee_id=attendee_id,
            status=status_filter,
        )

    def _get_registration_for_update(self, registration_id: int) -> Registration:
        registration = self.registrations.get_for_update(registration_id)
        if registration is None:
            raise BusinessError(
                "REGISTRATION_NOT_FOUND",
                "A inscricao informada nao existe.",
                {"registration_id": registration_id},
                status.HTTP_404_NOT_FOUND,
            )
        return registration

