from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = Field(
        "postgresql+psycopg://eventos:eventos@db:5432/eventos",
        alias="DATABASE_URL",
    )
    secret_key: str = Field("change-me-in-local-dev", alias="SECRET_KEY")
    port: int = Field(8000, alias="PORT")
    environment: str = Field("development", alias="ENVIRONMENT")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()

