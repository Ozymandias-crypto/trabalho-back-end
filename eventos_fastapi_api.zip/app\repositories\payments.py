from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.payment import Payment


class PaymentRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, payment: Payment) -> Payment:
        self.db.add(payment)
        self.db.flush()
        return payment

    def get_by_provider_reference(self, provider_reference: str) -> Payment | None:
        return self.db.scalar(select(Payment).where(Payment.provider_reference == provider_reference))

