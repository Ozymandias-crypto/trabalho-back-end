from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.models.enums import RegistrationStatus
from app.schemas.payment import PaymentRead


class RegistrationCreate(BaseModel):
    event_id: int = Field(gt=0)
    attendee_id: int = Field(gt=0)
    ticket_type_id: int = Field(gt=0)


class RegistrationRead(BaseModel):
    id: int
    event_id: int
    attendee_id: int
    ticket_type_id: int
    status: RegistrationStatus
    total_price_cents: int
    checked_in_at: datetime | None
    canceled_at: datetime | None
    created_at: datetime
    updated_at: datetime
    payment: PaymentRead | None = None

    model_config = ConfigDict(from_attributes=True)


class RegistrationPage(BaseModel):
    items: list[RegistrationRead]
    total: int
    limit: int
    offset: int

