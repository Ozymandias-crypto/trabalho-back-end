from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class TicketType(Base):
    __tablename__ = "ticket_types"
    __table_args__ = (
        CheckConstraint("price_cents >= 0", name="ck_ticket_types_price_non_negative"),
        CheckConstraint("capacity > 0", name="ck_ticket_types_capacity_positive"),
        CheckConstraint("sales_end > sales_start", name="ck_ticket_types_sales_window"),
        UniqueConstraint("event_id", "name", name="uq_ticket_types_event_name"),
        Index("ix_ticket_types_event_active", "event_id", "is_active"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    price_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    capacity: Mapped[int] = mapped_column(Integer, nullable=False)
    sales_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    sales_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    event: Mapped["Event"] = relationship(back_populates="ticket_types")
    registrations: Mapped[list["Registration"]] = relationship(back_populates="ticket_type")

