from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.attendee import Attendee


class AttendeeRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, attendee: Attendee) -> Attendee:
        self.db.add(attendee)
        self.db.flush()
        return attendee

    def get(self, attendee_id: int) -> Attendee | None:
        return self.db.scalar(select(Attendee).where(Attendee.id == attendee_id))

    def get_by_email(self, email: str) -> Attendee | None:
        return self.db.scalar(select(Attendee).where(Attendee.email == email))

