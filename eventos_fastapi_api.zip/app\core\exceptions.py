from typing import Any

from fastapi import Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError


class BusinessError(Exception):
    def __init__(
        self,
        error: str,
        message: str,
        details: dict[str, Any] | None = None,
        status_code: int = status.HTTP_400_BAD_REQUEST,
    ) -> None:
        self.error = error
        self.message = message
        self.details = details or {}
        self.status_code = status_code
        super().__init__(message)


async def business_error_handler(_: Request, exc: BusinessError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.error,
            "message": exc.message,
            "details": exc.details,
        },
    )


async def validation_error_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content=jsonable_encoder({
            "error": "VALIDATION_ERROR",
            "message": "Os dados enviados nao passaram na validacao.",
            "details": {"errors": exc.errors()},
        }),
    )


async def integrity_error_handler(_: Request, exc: IntegrityError) -> JSONResponse:
    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content={
            "error": "DATA_INTEGRITY_ERROR",
            "message": "A operacao viola uma restricao de integridade do banco.",
            "details": {"database_error": str(exc.orig)},
        },
    )
