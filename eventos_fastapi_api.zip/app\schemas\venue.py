from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class VenueCreate(BaseModel):
    name: str = Field(min_length=3, max_length=120)
    address: str = Field(min_length=5, max_length=255)
    capacity: int = Field(gt=0, le=100_000)
    is_active: bool = True


class VenueRead(BaseModel):
    id: int
    name: str
    address: str
    capacity: int
    is_active: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

