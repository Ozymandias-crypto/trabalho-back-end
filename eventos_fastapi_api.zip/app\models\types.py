from enum import Enum

from sqlalchemy import Enum as SAEnum


def enum_type(enum_cls: type[Enum]) -> SAEnum:
    return SAEnum(
        enum_cls,
        values_callable=lambda values: [item.value for item in values],
        native_enum=False,
        validate_strings=True,
    )

