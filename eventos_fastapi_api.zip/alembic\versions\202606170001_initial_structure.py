"""initial structure

Revision ID: 202606170001
Revises:
Create Date: 2026-06-17 16:20:00
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "202606170001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "venues",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("address", sa.String(length=255), nullable=False),
        sa.Column("capacity", sa.Integer(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("capacity > 0", name="ck_venues_capacity_positive"),
    )

    op.create_table(
        "events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("venue_id", sa.Integer(), sa.ForeignKey("venues.id"), nullable=False),
        sa.Column("title", sa.String(length=160), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("starts_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("ends_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("capacity_override", sa.Integer(), nullable=True),
        sa.Column("status", sa.String(length=32), server_default="draft", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("ends_at > starts_at", name="ck_events_end_after_start"),
        sa.CheckConstraint("capacity_override IS NULL OR capacity_override > 0", name="ck_events_capacity_override_positive"),
        sa.CheckConstraint("status IN ('draft', 'published', 'canceled', 'finished')", name="ck_events_status"),
    )
    op.create_index("ix_events_venue_id", "events", ["venue_id"])

    op.create_table(
        "ticket_types",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("event_id", sa.Integer(), sa.ForeignKey("events.id"), nullable=False),
        sa.Column("name", sa.String(length=80), nullable=False),
        sa.Column("price_cents", sa.Integer(), nullable=False),
        sa.Column("capacity", sa.Integer(), nullable=False),
        sa.Column("sales_start", sa.DateTime(timezone=True), nullable=False),
        sa.Column("sales_end", sa.DateTime(timezone=True), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("price_cents >= 0", name="ck_ticket_types_price_non_negative"),
        sa.CheckConstraint("capacity > 0", name="ck_ticket_types_capacity_positive"),
        sa.CheckConstraint("sales_end > sales_start", name="ck_ticket_types_sales_window"),
        sa.UniqueConstraint("event_id", "name", name="uq_ticket_types_event_name"),
    )
    op.create_index("ix_ticket_types_event_id", "ticket_types", ["event_id"])

    op.create_table(
        "attendees",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("email", sa.String(length=180), nullable=False),
        sa.Column("document", sa.String(length=40), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.UniqueConstraint("email", name="uq_attendees_email"),
    )
    op.create_index("ix_attendees_email", "attendees", ["email"])

    op.create_table(
        "registrations",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("event_id", sa.Integer(), sa.ForeignKey("events.id"), nullable=False),
        sa.Column("attendee_id", sa.Integer(), sa.ForeignKey("attendees.id"), nullable=False),
        sa.Column("ticket_type_id", sa.Integer(), sa.ForeignKey("ticket_types.id"), nullable=False),
        sa.Column("status", sa.String(length=32), server_default="pending_payment", nullable=False),
        sa.Column("total_price_cents", sa.Integer(), nullable=False),
        sa.Column("checked_in_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("canceled_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("total_price_cents >= 0", name="ck_registrations_total_non_negative"),
        sa.CheckConstraint("status IN ('pending_payment', 'confirmed', 'checked_in', 'canceled')", name="ck_registrations_status"),
        sa.UniqueConstraint("event_id", "attendee_id", name="uq_registrations_event_attendee"),
    )
    op.create_index("ix_registrations_event_id", "registrations", ["event_id"])
    op.create_index("ix_registrations_attendee_id", "registrations", ["attendee_id"])
    op.create_index("ix_registrations_ticket_type_id", "registrations", ["ticket_type_id"])

    op.create_table(
        "payments",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("registration_id", sa.Integer(), sa.ForeignKey("registrations.id"), nullable=False),
        sa.Column("amount_cents", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(length=32), server_default="pending", nullable=False),
        sa.Column("provider_reference", sa.String(length=120), nullable=True),
        sa.Column("paid_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("refunded_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("amount_cents >= 0", name="ck_payments_amount_non_negative"),
        sa.CheckConstraint("status IN ('pending', 'paid', 'failed', 'refunded')", name="ck_payments_status"),
        sa.UniqueConstraint("registration_id", name="uq_payments_registration_id"),
        sa.UniqueConstraint("provider_reference", name="uq_payments_provider_reference"),
    )
    op.create_index("ix_payments_registration_id", "payments", ["registration_id"])


def downgrade() -> None:
    op.drop_index("ix_payments_registration_id", table_name="payments")
    op.drop_table("payments")
    op.drop_index("ix_registrations_ticket_type_id", table_name="registrations")
    op.drop_index("ix_registrations_attendee_id", table_name="registrations")
    op.drop_index("ix_registrations_event_id", table_name="registrations")
    op.drop_table("registrations")
    op.drop_index("ix_attendees_email", table_name="attendees")
    op.drop_table("attendees")
    op.drop_index("ix_ticket_types_event_id", table_name="ticket_types")
    op.drop_table("ticket_types")
    op.drop_index("ix_events_venue_id", table_name="events")
    op.drop_table("events")
    op.drop_table("venues")

