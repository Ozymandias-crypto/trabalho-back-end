from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class AttendeeCreate(BaseModel):
    name: str = Field(min_length=3, max_length=120)
    email: EmailStr
    document: str | None = Field(default=None, min_length=5, max_length=40)

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: EmailStr) -> str:
        return str(value).strip().lower()


class AttendeeRead(BaseModel):
    id: int
    name: str
    email: EmailStr
    document: str | None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

