from datetime import datetime

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.enums import EventStatus
from app.schemas.event import EventAvailability, EventCreate, EventPage, EventRead
from app.schemas.ticket_type import TicketTypeCreate, TicketTypeRead
from app.services.events import EventService
from app.services.ticket_types import TicketTypeService

router = APIRouter(prefix="/events", tags=["events"])


@router.post("", response_model=EventRead, status_code=status.HTTP_201_CREATED)
def create_event(payload: EventCreate, db: Session = Depends(get_db)) -> EventRead:
    return EventService(db).create(payload)


@router.get("", response_model=EventPage)
def list_events(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    status_filter: EventStatus | None = Query(default=None, alias="status"),
    venue_id: int | None = Query(default=None, gt=0),
    starts_after: datetime | None = None,
    starts_before: datetime | None = None,
    db: Session = Depends(get_db),
) -> EventPage:
    items, total = EventService(db).list(
        limit=limit,
        offset=offset,
        status_filter=status_filter,
        venue_id=venue_id,
        starts_after=starts_after,
        starts_before=starts_before,
    )
    return EventPage(items=items, total=total, limit=limit, offset=offset)


@router.post("/{event_id}/ticket-types", response_model=TicketTypeRead, status_code=status.HTTP_201_CREATED)
def create_ticket_type(event_id: int, payload: TicketTypeCreate, db: Session = Depends(get_db)) -> TicketTypeRead:
    return TicketTypeService(db).create(event_id, payload)


@router.post("/{event_id}/publish", response_model=EventRead)
def publish_event(event_id: int, db: Session = Depends(get_db)) -> EventRead:
    return EventService(db).publish(event_id)


@router.post("/{event_id}/cancel", response_model=EventRead)
def cancel_event(event_id: int, db: Session = Depends(get_db)) -> EventRead:
    return EventService(db).cancel(event_id)


@router.get("/{event_id}/availability", response_model=EventAvailability)
def get_event_availability(event_id: int, db: Session = Depends(get_db)) -> EventAvailability:
    return EventService(db).availability(event_id)

