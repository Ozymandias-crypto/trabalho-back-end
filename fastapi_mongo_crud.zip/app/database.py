from pymongo import MongoClient

MONGO_URI = "mongodb://mongodb:27017"

client = MongoClient(MONGO_URI)
db = client["taskdb"]
collection = db["tasks"]
