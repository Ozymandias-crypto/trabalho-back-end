from fastapi import APIRouter
from app.database import collection
from app.models import Task
from bson import ObjectId

router = APIRouter()

def task_helper(task) -> dict:
    return {
        "id": str(task["_id"]),
        "title": task["title"],
        "description": task["description"],
        "completed": task["completed"],
        "priority": task["priority"]
    }

@router.post("/tasks")
def create_task(task: Task):
    result = collection.insert_one(task.dict())
    new_task = collection.find_one({"_id": result.inserted_id})
    return task_helper(new_task)

@router.get("/tasks")
def get_tasks():
    return [task_helper(task) for task in collection.find()]

@router.get("/tasks/{task_id}")
def get_task(task_id: str):
    task = collection.find_one({"_id": ObjectId(task_id)})
    return task_helper(task)

@router.put("/tasks/{task_id}")
def update_task(task_id: str, task: Task):
    collection.update_one(
        {"_id": ObjectId(task_id)},
        {"$set": task.dict()}
    )
    updated_task = collection.find_one({"_id": ObjectId(task_id)})
    return task_helper(updated_task)

@router.delete("/tasks/{task_id}")
def delete_task(task_id: str):
    collection.delete_one({"_id": ObjectId(task_id)})
    return {"message": "Task deleted successfully"}
