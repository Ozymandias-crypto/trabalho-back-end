# FastAPI + MongoDB CRUD

Projeto de CRUD utilizando FastAPI e MongoDB com Docker.

## Como rodar

docker-compose up --build

## Endpoints
- POST /tasks
- GET /tasks
- GET /tasks/{id}
- PUT /tasks/{id}
- DELETE /tasks/{id}
